__version__ = "0.2.3"
appid = "org.cunidev.gestures"
authors = ["Raffaele T. (cunidev)"]